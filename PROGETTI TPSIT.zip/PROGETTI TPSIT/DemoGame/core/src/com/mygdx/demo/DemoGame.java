package com.mygdx.demo;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

import javafx.application.Application.Parameters;

public class DemoGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	float imgx = 0;

	Camera cam;

	@Override
	public void create () {
		Parameters
		cam = new OrthographicCamera(4, 2);

		batch = new SpriteBatch();
		img = new Texture("badlogic.jpg");
	}
//setAspectRatio(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
	@Override
	public void render () {
		ScreenUtils.clear(1, 0, 0, 1);

		cam.update();
		batch.setProjectionMatrix(cam.combined);

		batch.begin();
		batch.draw(img, imgx, 0, 1, 1);
		batch.end();

		//imgx += 1;
		if(imgx > 800){
			imgx= - img.getWidth();
		}
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}
